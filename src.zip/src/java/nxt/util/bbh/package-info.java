/**
 * ByteBufferHelper. Utility classes for working with a ByteBuffer
 */
package nxt.util.bbh;